
export class Books{

                ID:any;
                Title:any;
                Author:any;
                Description:any;
                Price:any;
                Quantity:any;
                ImageUrl:any;
                Category:any;
                Condition:any;
                Language:any;
                Rating:any;

    }
