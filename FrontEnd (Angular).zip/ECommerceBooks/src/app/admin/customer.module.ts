export class Customer{
    
    CustomerID:any;
    Name:any;
    Email:any;
    Password:any;
    Address:any;
    ContactNumber:any;
    Role:any;


}
