export class Payment{


  Name:any;
  CardNumber:any;
  CVV:any;
  Amount:any;
  PaymentDate:any;
 


}
